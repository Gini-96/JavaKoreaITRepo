package javabasic.teamproject;

// 플레이 진행중 생기는 충돌에 관한 모든 예외처리를 진행 할 클래스
public class QuizException extends Exception{

	private static final long serialVersionUID = 61008648463711648L;


	

	
}
