package javabasic.teamproject;

// 클라이언트 (플레이어) 서버의 메인 클래스
public class QuizServerMain {

	public static void main(String[] args) {
		new QuizServer().startServer();
	}

}// class
